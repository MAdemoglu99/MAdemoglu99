﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestAPI.Resources
{
    public class SliderResource
    {
        public int Id { get; set; }
        public string Resim { get; set; }
        public string SliderAciklama { get; set; }
        public string SliderLink { get; set; }
    }
}
